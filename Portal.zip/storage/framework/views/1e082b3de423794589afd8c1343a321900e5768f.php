
<?php $__env->startSection('title','School Personal Profile'); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="dashboard-title fl-wrap">
    <!-- Register content-->
    <div class="col-md-12">
        <!-- profile-edit-container-->
        <div class="profile-edit-container fl-wrap block_box">
            <div class="RegistrationForm">
                <form class="SchoolRegisterForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="school_id" value="<?php echo e($data->school_id ?? ''); ?>">
                    <input type="hidden" name="slug" id="slug" value="<?php echo e($data->school_slug ?? ''); ?>">
                    <div class="custom-form">
                        <div class="row">
                            <div class="col-sm-6">
                                <label>School Name <small class="text-primary">*</small> <i
                                        class="fal fa-user"></i></label>
                                <input type="text" class="required" placeholder="School Name" name="school_name"
                                    id="school_name" value="<?php echo e($data->school_name ?? ''); ?>" onkeyup="SchoolSlug()" />
                            </div>
                            <div class="col-md-6">
                                <label>Syllabus <small class="text-primary">*</small></label>
                                <div class="listsearch-input-item">
                                    <select name="syllabus_type" id="syllabus_type"
                                        class="chosen-select no-search-select required">
                                        <option>CBSE</option>
                                        <option>CBIC</option>
                                        <option>SSC</option>
                                        <option>HSC</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>Starting Fees <small class="text-primary">*</small><i
                                        class="far fa-rupee-sign"></i> </label>
                                <input type="text" class="required" placeholder="Starting Fees" name="starting_fees"
                                    id="starting_fees" value="<?php echo e($data->starting_fees ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label>Phone <small class="text-primary">*</small><i class="far fa-phone"></i>
                                </label>
                                <input type="text" class="required" placeholder="School Phone Number"
                                    name="school_contact_number" id="school_contact_number"
                                    value="<?php echo e($data->school_contact_number ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label>School Whatsapp <small class="text-primary">*</small><i
                                        class="fab fa-whatsapp"></i> </label>
                                <input type="text" class="required" placeholder="School Whatsapp Number"
                                    name="school_whatsapp" id="school_whatsapp_number"
                                    value="<?php echo e($data->school_whatsapp ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> School City <small class="text-primary">*</small><i
                                        class="far fa-map-marked-alt"></i> </label>
                                <input type="text" class="required" placeholder="School City " name="school_city"
                                    id="school_city" value="<?php echo e($data->school_city ?? ''); ?>" onkeyup="SchoolSlug()" />
                            </div>
                            <div class="col-sm-6">
                                <label> Pincode <small class="text-primary">*</small><i
                                        class="fas fa-search-location"></i> </label>
                                <input type="text" class="required" placeholder="School Pincode" name="school_pin_code"
                                    id="school_pin_code" value="<?php echo e($data->school_pin_code ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Address <small class="text-primary">*</small><i
                                        class="fas fa-map-marker-alt"></i> </label>
                                <input type="text" class="required" placeholder="School Address" name="school_address"
                                    id="school_address" value="<?php echo e($data->school_address ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Location <small class="text-primary">*</small><i class="far fa-paper-plane"></i>
                                </label>
                                <input type="text" class="required" placeholder="School Location" name="school_location"
                                    id="school_location" value="<?php echo e($data->school_location ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Latitude & Longitude <i class="fas fa-location"></i>
                                </label>
                                <input type="text" placeholder="Latitude & Longitude" name="school_latlng"
                                    id="school_latitude_&_longitude" value="<?php echo e($data->school_latlng ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Email <small class="text-primary">*</small><i class="fal fa-envelope"></i>
                                </label>
                                <input type="text" class="required" placeholder="School Email" name="school_email"
                                    id="school_email" value="<?php echo e($data->school_email ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Website <i class="far fa-globe"></i> </label>
                                <input type="text" placeholder="website.com" name="school_website" id="school_website"
                                    value="<?php echo e($data->school_website ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> Password <small class="text-primary">*</small><i class="fal fa-unlock"></i>
                                </label>
                                <input type="text" class="required" placeholder="Password" name="school_password"
                                    id="school_password" value="<?php echo e($data->school_password ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label> School Description <small class="text-primary">*</small><i
                                        class="fa fa-info"></i>
                                </label>
                                <input type="text" class="required" placeholder="Description" name="school_about"
                                    id="school_description" value="<?php echo e($data->school_about ?? ''); ?>" />
                            </div>
                            <div class="col-sm-6">
                                <label>School Logo <small class="text-primary">*</small></label>
                                <div class="listsearch-input-item fl-wrap">
                                    <div class="fuzone">
                                        <div class="fu-text">
                                            <span><i class="fal fa-images"></i> Click here
                                                or
                                                drop files
                                                to
                                                upload</span>
                                            <div class="photoUpload-files fl-wrap"></div>
                                        </div>
                                        <input type="file" class="upload" name="school_logo" id="school_logo"
                                            accept="image/*">
                                    </div>
                                    <div class="edit-frame">
                                        <img src="<?php echo e(url('public/portal_images/school_logo')); ?>/<?php echo e($data->school_logo ?? ''); ?>"
                                            alt="" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>School Image <small class="text-primary">*</small></label>
                                <div class="listsearch-input-item fl-wrap">
                                    <div class="fuzone">
                                        <div class="fu-text">
                                            <span><i class="fal fa-images"></i> Click here
                                                or
                                                drop files
                                                to
                                                upload</span>
                                            <div class="photoUpload-files fl-wrap"></div>
                                        </div>
                                        <input type="file" class="upload" name="school_image" id="school_image"
                                            accept="image/*">
                                    </div>
                                    <div class="edit-frame">
                                        <img src="<?php echo e(url('public/portal_images/school_images')); ?>/<?php echo e($data->school_image ?? ''); ?>"
                                            alt="" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text">
                            <br>
                            <div id="error"></div>
                        </div>
                        <button type="button" class="register-btn btn color2-bg float-btn"
                            onclick="RegisterSchool()">Update<i class="fal fa-user-plus"></i></button>

                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- Register content end-->
</div>

<!-- === Selected Study Pattern ===  -->
<!-- === Image Model === -->
<div class="main-register-wrap modal_2">
    <div class="reg-overlay_2"></div>
    <div class="main-register-holder tabs-act">
        <div class="main-register fl-wrap  modal_main_2">
            <div class="main-register_title">Welcome to
                <span><strong>Campus</strong>Connect<strong>.</strong></span>
            </div>
            <div class="close-reg close-2"><i class="fal fa-times"></i></div>
            <!--tabs -->
            <div class="tabs-container">
                <div class="cropper-img-area">
                    <img src="<?php echo e(url('public/images/bg/29.jpg')); ?>" alt="" class="img-fluid img-preview">
                </div>
                <div class="crop-btn">
                    <button type="button" class=" b-none crop-img-btn btn color2-bg float-btn">Save <i
                            class="fas fa-save"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ### Modal ### -->
<div class="main-register-wrap modal_3">
    <div class="reg-overlay_3"></div>
    <div class="main-register-holder tabs-act">
        <div class="main-register fl-wrap  modal_main_3">
            <div class="main-register_title">Welcome to
                <span><strong>Campus</strong>Connect<strong>.</strong></span>
            </div>
            <div class="close-reg close-3"><i class="fal fa-times"></i></div>
            <!--tabs -->
            <div class="tabs-container">
                <div class="cropper-img-area">
                    <img src="<?php echo e(url('public/images/bg/')); ?>" alt="" class="img-fluid img-preview-2">
                </div>
                <div class="crop-btn">
                    <button type="button" class=" b-none crop-img-btn-2 btn color2-bg float-btn">Save <i
                            class="fas fa-save"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- === Image Model === -->

<!-- === Selected Study Pattern ===  -->


<!-- === Script === -->
<script>
// --- === Slug Creating Function === --- \\
function SchoolSlug() {
    let file_value = $("#school_name").val().trim();
    let slug = file_value;
    slug = slug.replaceAll(/[^a-zA-Z ]/g, '');
    slug = slug.replaceAll(" ", "-") + "-" + $("#school_city ").val().trim();
    $('#slug').val(slug);
}
SchoolSlug();
// --- === Slug Creating Function === --- \\

$('#syllabus_type option').filter(function(i, e) {
    if ($(e).val() == "<?php echo e($data->syllabus_type ?? ''); ?>") {
        $(e).prop('selected', true);
    }
    return $(e).val() == "<?php echo e($data->syllabus_type ?? ''); ?>"
})

var school_logo = $("#school_logo");
var school_image = $("#school_image");
var logo = ""
var NewSchoolImage = ""
var canvas_logo = ""
var canvas_image = ""
var getLogoBase64 = ""
var getImageBase64 = ""

school_logo.on('change', function() {
    var files = this.files;
    if (files && files.length > 0) {
        var photo = files[0];
        var reader = new FileReader();
        reader.onload = function(event) {
            var image = $('.img-preview')[0];
            image.src = event.target.result;
            logo = new Cropper(image, {
                viewMode: 1,
                aspectRatio: 1,
                maxCropBoxWidth: 150,
                maxCropBoxHeight: 150,
                responsive: true,
            });
            ModalOpen();
        };
        reader.readAsDataURL(photo);
    }
});
school_image.on('change', function() {
    var files = this.files;
    if (files && files.length > 0) {
        var photo = files[0];
        var reader = new FileReader();
        reader.onload = function(event) {
            var image = $('.img-preview-2')[0];
            image.src = event.target.result;
            NewSchoolImage = new Cropper(image, {
                aspectRatio: 6 / 4,
                responsive: true,
                viewMode: 3,
            });
            ModalOpen2();
        };
        reader.readAsDataURL(photo);
    }
});

$(".crop-img-btn").click(function(e) {
    e.preventDefault()
    canvas_logo = logo.getCroppedCanvas({
        width: 150,
        height: 150,
        imageSmoothingQuality: 'high',
    });
    var crop_logo = canvas_logo.toBlob(function(blob) {
        url = URL.createObjectURL(blob);
        var reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = function() {
            getLogoBase64 = reader.result;
        }
    });
    if (getLogoBase64 != "") {
        $('.modal_2 , .reg-overlay_2').fadeOut(200);
        $("html, body").removeClass("hid-body");
        $(".modal_main_2").removeClass("vis_mr");
        logo.destroy();
    }
})
$(".crop-img-btn-2").click(function(e) {
    e.preventDefault()
    canvas_image = NewSchoolImage.getCroppedCanvas({
        width: 600,
        height: 400,
        imageSmoothingQuality: 'high',
    });
    var crop_image = canvas_image.toBlob(function(blob) {
        url = URL.createObjectURL(blob);
        var reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = function() {
            getImageBase64 = reader.result;
        }
    });


    if (getImageBase64 != "") {
        $('.modal_3 , .reg-overlay_3').fadeOut(200);
        $("html, body").removeClass("hid-body");
        $(".modal_main_3").removeClass("vis_mr");
        NewSchoolImage.destroy();
    }
})

function RegisterSchool() {

    var fields = $("input[class*='required']");
    for (let i = 0; i <= fields.length; i++) {
        if ($(fields[i]).val() === '') {
            var currentElement = $(fields[i]).attr('id');
            var value = currentElement.replaceAll('_', ' ');
            $("#error").show().addClass('alert alert-danger').html('The ' + value + ' field is required.');
            return false;
        } else {
            $("#error").hide().removeClass().html('');
        }
    }


    const form = document.querySelector('.SchoolRegisterForm');
    const formData = new FormData(form);



    // -- Form Data Append -- \\
    var school_logo = getLogoBase64;
    var school_image = getImageBase64;

    formData.append('school_logo', school_logo)
    formData.append('school_image', school_image)
    formData.append('old_logo', '<?php echo e($data->school_logo ?? '
        '); ?>')
    formData.append('old_image', '<?php echo e($data->school_image ?? '
        '); ?>')
    // -- Form Data Append -- \\


    $.ajax({
        type: "POST",
        url: "<?php echo e(route('SchoolProfileUpdate')); ?>",
        data: formData,
        processData: false,
        contentType: false,
        beforeSend: function() {
            $(".register-btn").prop('disabled', true)
        },
        success: function(data) {
            $(".register-btn").prop('disabled', false)
            if (data['success'] == true) {
                $("#error").show().addClass('alert alert-success').html(data['message']);
                location.reload();
            } else if (data['validate'] == true) {
                $("#error").show().addClass('alert alert-danger').html(data['message'][0]);
            } else {
                $("#error").show().addClass('alert alert-danger').html(data['message']);
            }
        }
    })
}
</script>
<!-- === Script === -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Components.SchoolLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Schools/SchoolProfile.blade.php ENDPATH**/ ?>