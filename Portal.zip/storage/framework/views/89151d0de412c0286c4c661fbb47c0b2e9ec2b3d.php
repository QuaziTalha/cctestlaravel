<div class="gallery-item restaurant events">
    <!-- listing-item  -->
    <div class="listing-item">
        <article class="geodir-category-listing fl-wrap">
            <div class="geodir-category-img">
                <a href="javascript:void(0)" class="geodir-category-img-wrap fl-wrap">
                    <img src="<?php echo e(url('public/portal_images/blog_images/')); ?>/<?php echo e($data->blog_image ?? ''); ?>" alt="">
                </a>
                <div class="geodir_status_date color-bg"><i class="fal fa-clock"></i><?php echo e($data->blog_date ?? ''); ?></div>
            </div>
            <div class="geodir-category-content fl-wrap title-sin_item">
                <div class="geodir-category-content-title fl-wrap">
                    <div class="geodir-category-content-title-item">
                        <h3 class="title-sin_map"><a href="javascript:void(0)"><?php echo e(Str::limit($data->blog_title,30,'..')  ?? ''); ?></a></h3>
                    </div>
                </div>
                <div class="geodir-category-text fl-wrap">
                    <p class="small-text"><?php echo e(strip_tags(Str::limit($data->blog_description,100,'..')  ?? '')); ?></p>
                </div>
            </div>
        </article>
    </div>
    <!-- listing-item end -->
</div><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Components/Partials/BlogCard.blade.php ENDPATH**/ ?>