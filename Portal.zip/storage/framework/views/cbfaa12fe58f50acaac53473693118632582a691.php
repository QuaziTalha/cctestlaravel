
<?php $__env->startSection('title','Home || Campus Connect'); ?>
<?php $__env->startSection('content'); ?>

<!-- === School Detail Section === -->
<section class="listing-hero-section hidden-section" data-scrollax-parent="true" id="sec1">
    <div class="bg-parallax-wrap">
        <div class="bg par-elem "
            data-bg="<?php echo e(url('/')); ?>/public/portal_images/school_images/<?php echo e($schools->school_image ?? ''); ?>"
            data-scrollax="properties: { translateY: '30%' }"></div>
        <div class="overlay"></div>
    </div>
    <div class="container">
        <div class="list-single-header-item  fl-wrap">
            <div class="row">
                <div class="col-md-9">
                    <h1><?php echo e($schools->school_name ?? ''); ?> <span class="verified-badge"><i class="fal fa-check"></i></span>
                    </h1>
                    <div class="geodir-category-location fl-wrap"><a href="#"><i class="fas fa-map-marker-alt"></i>
                            <?php echo e($schools->school_address ?? ''); ?>,<?php echo e($schools->school_city ?? ''); ?>

                            <?php echo e($schools->school_pin_code ?? ''); ?></a> <a href="#"> <i
                                class="fal fa-phone"></i><?php echo e($schools->school_contact_number ?? ''); ?></a> <a href="#"><i
                                class="fal fa-envelope"></i> <?php echo e($schools->school_email ?? ''); ?></a></div>
                </div>
            </div>
        </div>
        <div class="list-single-header_bottom fl-wrap">
            <a class="listing-item-category-wrap" href="#">
                <div class="listing-item-category  red-bg"><i class="fal fa-school"></i></div>
                <span>School</span>
            </a>
            <div class="list-single-author"> <a href="javascript:void(0)"><span class="author_avatar"> <img alt=''
                            src="<?php echo e(url('/')); ?>/public/portal_images/school_logo/<?php echo e($schools->school_logo ?? ''); ?>">
                    </span><?php echo e(Str::limit($schools->school_name,10,'..')  ?? ''); ?></a></div>
        </div>
    </div>
</section>
<!-- scroll-nav-wrapper-->
<div class="scroll-nav-wrapper fl-wrap">
    <div class="container">
        <nav class="scroll-nav scroll-init">
            <ul class="no-list-style">
                <li><a class="act-scrlink" href="#sec1"><i class="fal fa-images"></i> Top</a></li>
                <li><a href="#sec2"><i class="fal fa-info"></i>Details</a></li>
                <li><a href="#sec3"><i class="fal fa-image"></i>Gallery</a></li>
                <li><a href="#sec4"><i class="fal fa-clipboard"></i>Course</a></li>
                <li><a href="#sec5"><i class="fal fa-graduation-cap"></i>Eligibilities</a></li>
            </ul>
        </nav>
    </div>
</div>
<!-- scroll-nav-wrapper end-->
<section class="gray-bg no-top-padding">
    <div class="container">
        <div class="clearfix"></div>
        <div class="row">
            <!-- list-single-main-wrapper-col -->
            <div class="col-md-8">
                <!-- list-single-main-wrapper -->
                <div class="list-single-main-wrapper fl-wrap" id="sec2">
                    <div class="list-single-main-media fl-wrap">
                        <img src="images/all/48.jpg" class="respimg" alt="">
                        <a href="https://vimeo.com/70851162" class="promo-link   image-popup"><i
                                class="fal fa-video"></i><span>Promo Video</span></a>
                    </div>
                    <!-- list-single-main-item -->
                    <div class="list-single-main-item fl-wrap block_box">
                        <div class="list-single-main-item-title">
                            <h3>Description</h3>
                        </div>
                        <div class="list-single-main-item_content fl-wrap">
                            <p><?php echo e($schools->school_about ?? ''); ?></p>
                            <a href="<?php echo e($schools->school_website ?? ''); ?>" target="_blank"
                                class="btn color2-bg    float-btn">Visit Website<i class="fal fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <!-- list-single-main-item end -->
                    <!-- list-single-main-item -->
                    <div class="list-single-main-item fl-wrap block_box h-215px">
                        <div class="list-single-main-item-title">
                            <h3>School Features</h3>
                        </div>
                        <div class="list-single-main-item_content fl-wrap">
                            <div class="listing-features fl-wrap">
                                <ul class="no-list-style">
                                    <?php if(count($schools->facility)>0): ?>
                                    <?php $__currentLoopData = $schools->facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="#">
                                            <img src="<?php echo e(url('/')); ?>/public/portal_images/school_facility/<?php echo e($facility->facility_picture ?? ''); ?>"
                                                alt="<?php echo e($facility->facility_name ?? ''); ?>">
                                            <?php echo e($facility->facility_name ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <li>
                                        <h3 class="text-grey">There are no facility uploaded</h2>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- list-single-main-item end -->
                    <!-- list-single-main-item-->
                    <div class="list-single-main-item fl-wrap block_box" id="sec3">
                        <div class="list-single-main-item-title">
                            <h3>Gallery / Photos</h3>
                        </div>
                        <div class="list-single-main-item_content fl-wrap">
                            <div class="single-carousel-wrap fl-wrap lightgallery">
                                <div class="sc-next sc-btn color2-bg"><i class="fas fa-caret-right"></i></div>
                                <div class="sc-prev sc-btn color2-bg"><i class="fas fa-caret-left"></i></div>
                                <div class="single-carousel fl-wrap full-height">
                                    <div class="swiper-container">
                                        <div class="swiper-wrapper">
                                            <!-- swiper-slide-->
                                            <?php if(count($schools->gallery)>0): ?>
                                            <?php $__currentLoopData = $schools->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="swiper-slide">
                                                <div class="box-item">
                                                    <img src="<?php echo e(url('/')); ?>/public/portal_images/school_gallery/<?php echo e($gallery->gallery_image ??''); ?>"
                                                        alt="">
                                                    <a href="<?php echo e(url('/')); ?>/public/portal_images/school_gallery/<?php echo e($gallery->gallery_image ??''); ?>"
                                                        class="gal-link popup-image"><i class="fa fa-search"></i></a>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <li>
                                                <h3 class="text-grey">There are no gallery uploaded</h2>
                                            </li>
                                            <?php endif; ?>
                                            <!-- swiper-slide end-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- list-single-main-item end -->
                    <!-- list-single-main-item-->
                    <div class="list-single-main-item fl-wrap block_box" id="sec4">
                        <div class="list-single-main-item-title">
                            <h3>School Course</h3>
                        </div>
                        <div class="list-single-main-item_content fl-wrap">
                            <table class=" table table-striped table-bordered dataTable display ">
                                <thead>
                                    <tr>
                                        <th class="bg-info">Course</th>
                                        <th class="bg-light">Course Fees</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($schools->courses) > 0): ?>
                                    <?php $__currentLoopData = $schools->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($courses->course_name ?? ''); ?></td>
                                        <td><?php echo e($courses->course_fees ?? ''); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan='2'>There is no course uploaded.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- list-single-main-item end -->
                    <!-- list-single-main-item -->
                    <div class="list-single-main-item fl-wrap block_box" id="sec5">
                        <div class="list-single-main-item-title">
                            <h3>School Eligibilities</h3>
                        </div>

                        <div class="list-single-main-item_content fl-wrap text-left">
                            <ul class="no-list-style eligibity-ul">
                                <?php if(count($schools->eligibility)>0): ?>
                                <?php $__currentLoopData = $schools->eligibility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eligibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li> <?php echo e($eligibility->eligibity  ?? ''); ?> <br>
                                    <span><small><?php echo e($eligibility->eligibity_value ?? ''); ?></small></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <li>
                                    <h3 class="text-grey">There are no eligibity uploaded</h2>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <!-- list-single-main-item end -->
                </div>
            </div>
            <!-- list-single-main-wrapper-col end -->
            <!-- list-single-sidebar -->
            <div class="col-md-4">
                <!--box-widget-item -->
                <div class="box-widget-item fl-wrap block_box">
                    <div class="box-widget-item-header">
                        <h3>School Detail</h3>
                    </div>
                    <div class="box-widget opening-hours fl-wrap">
                        <div class="box-widget-content">
                            <ul class="no-list-style">
                                <li class="no-class"><span class="opening-hours-day">Starting Fees </span><span
                                        class="opening-hours-time"><?php echo e($schools->starting_fees ?? ''); ?></span></li>
                                <li class="no-class"><span class="opening-hours-day">Latitude & Longitude </span><span
                                        class="opening-hours-time"><?php echo e($schools->school_latlng ?? ''); ?></span></li>
                                <li class="no-class"><span class="opening-hours-day">Email </span><a
                                        href="mailto:<?php echo e($schools->school_email ?? ''); ?>"><span
                                            class="opening-hours-time"><?php echo e($schools->school_email ?? ''); ?></span></a></li>
                                <li class="no-class"><span class="opening-hours-day">Contact Number </span><a
                                        href="tel:<?php echo e($schools->school_contact_number ?? ''); ?>"><span
                                            class="opening-hours-time"><?php echo e($schools->school_contact_number ?? ''); ?></span></a>
                                </li>
                                <li class="no-class"><span class="opening-hours-day">Whatsapp Number </span><a
                                        href="https://wa.me/<?php echo e($schools->school_whatsapp ?? ''); ?>" target="_blank"><span
                                            class="opening-hours-time"><?php echo e($schools->school_whatsapp ?? ''); ?></span></a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
                <!--box-widget-item end -->

                <!--box-widget-item -->
                <div class="box-widget-item fl-wrap block_box">
                    <div class="box-widget-item-header">
                        <h3>Location / Contacts </h3>
                    </div>
                    <div class="box-widget">
                        <div class="map-container">
                        <?php if($schools->school_latlng != " " && $schools->school_latlng != null): ?>
                            <?php
                                $NewLatLongArr = explode(',', $schools->school_latlng ?? '');
                                $NewLat = $NewLatLongArr[0];
                                $NewLng = $NewLatLongArr[1];
                            ?>
                            <div id="singleMap" data-latitude="<?php echo e($NewLat ?? ''); ?>" data-longitude="<?php echo e($NewLng ?? ''); ?>"
                                data-mapTitle="Our Location"></div>
                            <?php endif; ?>
                        </div>
                        <div class="box-widget-content bwc-nopad">
                            <div class="list-author-widget-contacts list-item-widget-contacts bwc-padside">
                                <ul class="no-list-style">
                                    <li><span><i class="fal fa-map-marker"></i> Adress :</span> <a
                                            href="#"><?php echo e($schools->school_address ?? ''); ?></a></li>
                                    <li><span><i class="fal fa-phone"></i> Phone :</span> <a
                                            href="tel:<?php echo e($schools->school_contact_number ?? ''); ?>"><?php echo e($schools->school_contact_number ?? ''); ?></a>
                                    </li>
                                    <li><span><i class="fal fa-envelope"></i> Mail :</span> <a
                                            href="mailto:<?php echo e($schools->school_email ?? ''); ?>"><?php echo e($schools->school_email ?? ''); ?></a>
                                    </li>
                                    <li><span><i class="fal fa-browser"></i> Website :</span> <a target="_blank"
                                            href="<?php echo e($schools->school_website ?? ''); ?>"><?php echo e($schools->school_website ?? ''); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!--box-widget-item end -->
                <?php if(!empty($schools->brochure[0]->brochure_file)): ?>
                <a href="<?php echo e(url('/')); ?>/public/portal_images/school_brochure/<?php echo e($schools->brochure[0]->brochure_file ?? ''); ?>"
                    download class="btn color2-bg url_btn float-btn btn-block"> Download College Info
                    <i class="fal fa-bookmark"></i>
                </a>
                <?php endif; ?>
            </div>
            <!-- list-single-sidebar end -->
        </div>
    </div>
</section>
<div class="limit-box fl-wrap"></div>
<!-- === School Detail Section === -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Components.Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Web/Home/SchoolDetail.blade.php ENDPATH**/ ?>