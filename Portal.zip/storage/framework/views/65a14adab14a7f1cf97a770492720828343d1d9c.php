
<?php $__env->startSection('title','School Personal Profile'); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="dashboard-title fl-wrap">
    <h3>Your Statistics</h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Components.SchoolLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Schools/SchoolDashboard.blade.php ENDPATH**/ ?>