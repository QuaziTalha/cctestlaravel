
<?php $__env->startSection('title','School Daily Blog'); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="card dashboard-list-box mar-dash-list fl-wrap">
    <div class="card-header">

        <div class="d-flex justify-content-between">
            <h1 class="mt-7">School Blog</h1>
            <a href="<?php echo e(route('SchoolBlogForm')); ?>" class="add-btn color-bg">Add Brochure</a>
        </div>
    </div>
</div>

<!-- === Content ===  -->
<div class="dashboard-list-box mar-dash-list fl-wrap broucher-list mt-2">
    <br>
    <div class="bg-white loader d-none">
        <img src="<?php echo e(url('public/portal_images/loader_gif.gif')); ?>" alt="" width="150">
    </div>
</div>
<!-- === Content ===  -->

<!-- === Main Script === -->
<script>
function GetBlog() {
    $.ajax({
        type: "GET",
        url: "<?php echo e(route('GetBlogs')); ?>",
        beforeSend: function() {
            $(".loader").removeClass('d-none')
        },
        success: function(data) {
            $(".loader").addClass('d-none')
            var data = JSON.parse(data);
            var brochure = "";
            var heading = "";
            if (data.length > 0) {
                $.each(data, function(index, value) {
                    brochure +=
                        "<div class='dashboard-list fl-wrap'><div class='dashboard-message'><div class='booking-list-contr'><a href='#' class='color-bg tolt' data-microtip-position='left' data-tooltip='Edit'><i class='fal fa-edit'></i></a><a href='javascript:void(0)' class='red-bg tolt' data-microtip-position='left' data-tooltip='Delete' onclick=FacilityRemove(" + value.blog_id  + ",'" + value.blog_image +"')><i class='fal fa-trash'></i></a></div><div class='dashboard-message-text'><img src='<?php echo e(url('/')); ?>/public/portal_images/school_facility/" + value.blog_image +"' alt=''><h4><a href='javascript:void(0)'>" + value.blog_title + "</a></h4>    <div class='geodir-category-location clearfix'><a href='javascript:void(0)'> " + value.blog_description + "</a></div></div></div></div>";
                    $(".broucher-list").html(brochure)
                });
            } else {
                heading += "<h1>You do not have any brochures uploaded.</h1>"
                $(".broucher-list").html(heading)
            }
        }
    })
}
GetBlog();
</script>
<!-- === Main Script === -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Components.SchoolLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Schools/SchoolBlog.blade.php ENDPATH**/ ?>