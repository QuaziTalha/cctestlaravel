<?php if(!empty($schools)): ?>
<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--  gallery-item-->
<?php echo $__env->make('Components.Partials.ListCard',['data' => $row], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- gallery-item  end-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Campus_Portal\resources\views/Components/PaginationCard.blade.php ENDPATH**/ ?>